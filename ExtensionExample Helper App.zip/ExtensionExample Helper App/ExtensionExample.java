// ExtensionExample.java
// Copyright (c) MIT Media Laboratory, 2013
//
// This example Scratch helper app runs a server that allows Scratch to connect
// play a beep sound and set and get the value of fake variable named 'volume'.
//
// Built using the JSON-simple library from http://code.google.com/p/json-simple/
// (This library gets built into the .jar file.)
// You can download the small (~25k) .jar file and put it in your Java extensions folder.
// Or you can put the JSON-simple source folder in the directory with your helper app
// Java sources and Java will compile it automatically (at least, that works on Mac OS).

import java.awt.Toolkit;
import java.io.*;
import java.net.*;
import java.util.*;
import org.json.simple.*;

public class ExtensionExample {

	public static void main(String[] args) throws IOException {
		// Run the server. Create a server socket, accept connections, and start an instance of MsgServer
		// for each connection to handle that connection a separate thread. Throws an exceptions and exits
		// if the server socket cannot be opened (e.g. that port is in use).
		InetAddress addr = InetAddress.getLocalHost();
		System.out.println("ExtensionExample helper app started on " + addr.toString());
		
		ServerSocket serverSock = new ServerSocket(MsgServer.PORT);
		while (true) {
			Socket sock = serverSock.accept();
			MsgServer msgServer = new MsgServer(sock);
			new Thread(msgServer).start();
		}
	}
}

class MsgServer implements Runnable {

	public static final int PORT = 12345; // the ExtensionExample port number

	private Socket sock;
	InputStream sockIn;
	OutputStream sockOut;

	private String msgBuf = "";	// incomplete message awaiting more data (does not include '\n')
	private JSONArray params;	// parameters for the current message

	private int volume = 8;

	public MsgServer(Socket socket) {
		// Initialize this instance to handle requests on the given socket.
		sock = socket;
	}

	public void run() {
		try {
			msgLoop();
		} catch (IOException e) {
			try { sock.close(); } catch (IOException ignored) { } // try to close socket, ignore errors
			e.printStackTrace(System.err);
		}
	}
	
	private void msgLoop() throws IOException {
		// The loop in this method handles all communications for this server session.
		// Communications in both directions is broken into a sequence of messages separated by
		// newline characters ('\n'). Messages are respresented in JSON with no embedded newlines.
		// (Newlines within JSON string are encoded as '\n').

		sockIn = sock.getInputStream();
		sockOut = sock.getOutputStream();
		byte[] buf = new byte[5000];

		System.err.println("-----Connected-----.");
		while (true) {
			int bytes_read = sockIn.read(buf, 0, buf.length);
			if (bytes_read < 0) break; // client closed socket
			String s = new String(Arrays.copyOf(buf, bytes_read));
			if (s.equals("<policy-file-request/>\0")) {
				// To support the Flash security model, the server responds to a policy file request
				// by sending a policy file string that allows Flash to connect to this port. The
				// policy request and response are terminated with null characters ('\0') rather than
				// newlines. The policy exchange happens before message exchange begins.
				sendPolicyRequest(sockOut);
			} else {
				msgBuf += s;
				int i;
				while ((i = msgBuf.indexOf('\n')) >= 0) {
					// While msgBuf includes a newline, extract a message and handle it.
					// If a message is not yet complete (no newline), msgBuf holds the partial
					// message until more data arrives.
					String msg = msgBuf.substring(0, i);
					msgBuf = msgBuf.substring(i + 1, msgBuf.length());
					try {
						handleMsg(msg);
					} catch (Exception e) {
						// Errors while handling a message print the stack but do not kill the server.
						System.err.println("problem handling: " + msg);
						e.printStackTrace(System.err);
					}
				}
			}
		}
		sock.close();
		System.err.println("-----Closed-----");
	}
	
	private void sendPolicyRequest(OutputStream sockOut) throws IOException {
		// Send a Flash null-teriminated cross-domain policy file.
		String policyFile =
			"<cross-domain-policy>\n" +
			"  <allow-access-from domain=\"*\" to-ports=\"" + PORT + "\"/>\n" +
			"</cross-domain-policy>\n\0";
		byte[] outBuf = policyFile.getBytes();
		sockOut.write(outBuf, 0, outBuf.length);
		sockOut.flush();
	}
	
	private void handleMsg(String msg) throws Exception {
		// Handle a command.
		JSONObject msgObj = (JSONObject) JSONValue.parse(msg);
		String cmd = (String) msgObj.get("method");
		params = (JSONArray) msgObj.get("params");
		if (cmd.equals("playBeep")) {
			// play a system beep
			java.awt.Toolkit.getDefaultToolkit().beep();
		} else if (cmd.equals("setVolume")) {
			volume = intarg(0);
		} else if (cmd.equals("poll")) {
			String reply = "{\"method\": \"update\", \"params\": [";
			reply += "[ \"volume\", " + volume + "], "; // pretend t
			reply += "]}\n";
			byte[] outBuf = reply.getBytes();
			sockOut.write(outBuf, 0, outBuf.length);
		} else {
			System.err.println("unknown command: " + msg);
		}
	}

	private int intarg(int index) {
		// Return the integer parameter at the given index.
		// Assume the given parameter is a Number and coerce it to an int.
		return ((Number) params.get(index)).intValue();
	}

}
