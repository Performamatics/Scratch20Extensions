#!/bin/sh
javac ExtensionExample.java
jar -cfm ExtensionExample.jar manifest.mf *.class org/json/simple/*.class org/json/simple/parser/*.class
rm *.class org/json/simple/*.class org/json/simple/parser/*.class 